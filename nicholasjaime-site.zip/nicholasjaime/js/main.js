// ── Cursor ──────────────────────────────────────────────
const cursor = document.getElementById('cursor');
const ring   = document.getElementById('cursorRing');
let mx = 0, my = 0, rx = 0, ry = 0;

if (cursor && ring) {
  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    cursor.style.left = mx + 'px';
    cursor.style.top  = my + 'px';
  });

  (function animateRing() {
    rx += (mx - rx) * 0.12;
    ry += (my - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    requestAnimationFrame(animateRing);
  })();

  document.querySelectorAll('a, button, .masonry-item, .gallery-card').forEach(el => {
    el.addEventListener('mouseenter', () => {
      ring.style.width = '52px'; ring.style.height = '52px'; ring.style.opacity = '0.2';
    });
    el.addEventListener('mouseleave', () => {
      ring.style.width = '28px'; ring.style.height = '28px'; ring.style.opacity = '1';
    });
  });
}

// ── Page transitions ─────────────────────────────────────
const overlay = document.getElementById('pageTransition');

function navigateTo(href) {
  if (!overlay) { window.location.href = href; return; }
  overlay.classList.add('out');
  setTimeout(() => { window.location.href = href; }, 500);
}

document.addEventListener('DOMContentLoaded', () => {
  if (overlay) {
    overlay.style.opacity = '1';
    overlay.style.transition = 'none';
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        overlay.style.transition = 'opacity 0.5s ease';
        overlay.style.opacity = '0';
      });
    });
  }

  // Intercept internal links
  document.querySelectorAll('a[data-nav]').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(link.href);
    });
  });

  // Scroll reveal for masonry
  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('visible'), i * 60);
      }
    });
  }, { threshold: 0.05 });
  document.querySelectorAll('.masonry-item').forEach(el => observer.observe(el));

  // Set active dot
  const path = window.location.pathname;
  document.querySelectorAll('.side-nav a').forEach(a => {
    const href = a.getAttribute('href');
    if (
      (href === '/index.html' || href === '/') && (path === '/' || path === '/index.html') ||
      href !== '/' && href !== '/index.html' && path.startsWith(href.replace('index.html',''))
    ) {
      a.classList.add('active');
    }
  });
});

// ── Lightbox ─────────────────────────────────────────────
const lightbox = document.getElementById('lightbox');
const lbImg    = document.getElementById('lightboxImg');
const lbCap    = document.getElementById('lightboxCaption');

function openLightbox(src, caption) {
  if (!lightbox) return;
  lbImg.src = src;
  if (lbCap) lbCap.textContent = caption || '';
  lightbox.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  if (!lightbox) return;
  lightbox.classList.remove('open');
  document.body.style.overflow = '';
}

if (lightbox) {
  document.getElementById('lightboxClose')?.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });
}
